import "./index.css";
import "../css/animate.min.css";
import "./canvas.js";
import {
  addQipao,
  setPrizes,
  showPrizeList,
  setPrizeData,
  resetPrize
} from "./prizeList";
import { NUMBER_MATRIX } from "./config.js";
import { initGestureStopper, allowImmediateSpin } from "./gesture.js";

const ROTATE_TIME = 3000;
const ROTATE_LOOP = 1000;
const MIN_SPIN_MS = 1000; // минимум 1s до допуска жеста стоп
const SPIN_SPEED = 0.124; // ~на 30% медленнее, чем было (0.176 * 0.7)
const BASE_HEIGHT = 1080;
const DISPLAY_YEAR = 2026;

let TOTAL_CARDS,
  btns = {
    enter: document.querySelector("#enter"),
    lotteryBar: document.querySelector("#lotteryBar"),
    lottery: document.querySelector("#lottery")
  },
  prizes,
  ROW_COUNT = 7,
  COLUMN_COUNT = 17,
  HIGHLIGHT_CELL = [],
  // Текущий коэффициент масштабирования
  Resolution = 1,
  prizeIndexMap = new Map(),
  availablePrizePool = [],
  cardPrizeLayout = [],
  defaultPrizeType = null,
  gesturesReady = false;

let camera,
  scene,
  renderer,
  controls,
  threeDCards = [],
  targets = {
    table: [],
    sphere: []
  };

let requestSmoothStop;
let rotateScene = false;
let spinStartedAt = 0;

let selectedCardIndex = [],
  rotate = false,
  basicData = {
    prizes: [], // Информация о призах
    users: [], // Все участники
    luckyUsers: {}, // Победители
    leftUsers: [], // Не выигравшие (сохраняем для совместимости)
    awardedCounts: {}
  },
  interval,
  currentPrize,
  // Идёт розыгрыш
  isLotting = false,
  currentLuckys = [];

initAll();
function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
}

function ensureNameElement(element) {
  if (!element) {
    return null;
  }
  let nameEl = element.querySelector(".name");
  if (!nameEl) {
    nameEl = document.createElement("div");
    nameEl.className = "name";
    element.appendChild(nameEl);
  }
  return nameEl;
}

function applyNameSizing(nameEl, text) {
  if (!nameEl) {
    return;
  }
  nameEl.classList.remove("name--sm", "name--xs", "name--xxs");
  const length = text ? text.length : 0;
  if (length > 52) {
    nameEl.classList.add("name--xxs");
  } else if (length > 40) {
    nameEl.classList.add("name--xs");
  } else if (length > 28) {
    nameEl.classList.add("name--sm");
  }
}

function setCardLabel(element, label) {
  const nameEl = ensureNameElement(element);
  if (!nameEl) {
    return;
  }
  const safeLabel = label || "";
  nameEl.textContent = safeLabel;
  element.title = safeLabel;
  applyNameSizing(nameEl, safeLabel);
  if (safeLabel) {
    element.classList.remove("card-empty");
  } else {
    element.classList.add("card-empty");
  }
}

function getPrizeLabel(prize) {
  if (!prize) {
    return "";
  }
  if (prize.title && prize.title.trim()) {
    return prize.title.trim();
  }
  const sanitized = String(prize.text || "")
    .replace(/\s+/g, " ")
    .trim();
  const noNumbers = sanitized.replace(/\d[\d\s]*/g, "").replace(/\s+/g, " ").trim();
  return noNumbers || sanitized;
}

function normalizeLuckyData(raw) {
  const normalized = {};
  if (!raw || typeof raw !== "object") {
    return normalized;
  }
  Object.keys(raw).forEach(key => {
    const entries = Array.isArray(raw[key]) ? raw[key] : [];
    normalized[key] = entries.map(entry => {
      if (entry && typeof entry === "object" && !Array.isArray(entry)) {
        return entry;
      }
      if (Array.isArray(entry)) {
        return {
          type: Number(key),
          label: entry[1] || entry[0] || "",
          source: entry
        };
      }
      return {
        type: Number(key),
        label: String(entry || "")
      };
    });
  });
  return normalized;
}

function initialisePrizeState(luckyData) {
  prizeIndexMap = new Map();
  availablePrizePool = [];
  basicData.awardedCounts = {};
  basicData.luckyUsers = normalizeLuckyData(luckyData);

  prizes.forEach((prize, index) => {
    const label = getPrizeLabel(prize);
    prize.displayLabel = label;
    if (index === 0) {
      defaultPrizeType = prize.type;
    }
    prizeIndexMap.set(prize.type, { prize, index });
    if (prize.type === defaultPrizeType) {
      return;
    }
    const typeKey = String(prize.type);
    const awarded = (basicData.luckyUsers[typeKey] || []).length;
    basicData.awardedCounts[prize.type] = awarded;
    const remaining = Math.max((Number(prize.count) || 0) - awarded, 0);
    for (let i = 0; i < remaining; i++) {
      availablePrizePool.push(prize.type);
    }
  });

  shuffleArray(availablePrizePool);
}

function buildCardEntries() {
  const entries = [];
  const displayTypes = [];
  prizeIndexMap.forEach((info, type) => {
    if (info && info.prize.type !== defaultPrizeType) {
      displayTypes.push(type);
    }
  });

  if (displayTypes.length === 0) {
    for (let i = 0; i < TOTAL_CARDS; i++) {
      entries.push({ type: null, label: "" });
    }
    return entries;
  }

  let bag = [];
  for (let i = 0; i < TOTAL_CARDS; i++) {
    if (bag.length === 0) {
      bag = displayTypes.slice();
      shuffleArray(bag);
    }
    const type = bag.pop();
    const info = prizeIndexMap.get(type);
    entries.push({
      type,
      label: (info && info.prize && info.prize.displayLabel) || ""
    });
  }

  return entries;
}

function drawPrizeFromPool() {
  if (availablePrizePool.length === 0) {
    return null;
  }
  const index = Math.floor(Math.random() * availablePrizePool.length);
  const [type] = availablePrizePool.splice(index, 1);
  const info = prizeIndexMap.get(type);
  if (!info) {
    return null;
  }

  return {
    type,
    label: info.prize.displayLabel,
    text: info.prize.text,
    index: info.index,
    timestamp: Date.now()
  };
}

function markPrizeAwarded(record, options = {}) {
  if (!record || typeof record.type === "undefined") {
    return;
  }
  const type = record.type;
  basicData.awardedCounts[type] = (basicData.awardedCounts[type] || 0) + 1;
  const info = prizeIndexMap.get(type);
  if (info) {
    setPrizeData(info.index, basicData.awardedCounts[type], {
      highlight: !!options.highlight
    });
  }
}

function undoPrizeAward(record) {
  if (!record || typeof record.type === "undefined") {
    return;
  }
  const type = record.type;
  const current = basicData.awardedCounts[type] || 0;
  basicData.awardedCounts[type] = current > 0 ? current - 1 : 0;
  availablePrizePool.push(type);
  shuffleArray(availablePrizePool);
  const info = prizeIndexMap.get(type);
  if (info) {
    setPrizeData(info.index, basicData.awardedCounts[type], {
      clearHighlight: true
    });
  }
}

function updateAllPrizeDisplays(highlightType) {
  prizes.forEach((prize, index) => {
    if (prize.type === defaultPrizeType) {
      return;
    }
    const awarded = basicData.awardedCounts[prize.type] || 0;
    setPrizeData(index, awarded, {
      highlight: prize.type === highlightType
    });
  });
}

function refreshCardLayout() {
  cardPrizeLayout = buildCardEntries();
  for (let i = 0; i < threeDCards.length; i++) {
    changeCard(i, cardPrizeLayout[i] || {});
  }
}

function ensureGestureControl() {
  if (gesturesReady) {
    return;
  }
  gesturesReady = true;
  initGestureStopper({
    onStop: () => {
      if (isLotting && Date.now() - spinStartedAt > MIN_SPIN_MS) {
        requestSmoothStop && requestSmoothStop();
        btns.lottery.innerHTML = "Начать розыгрыш";
      }
    },
    onSpin: () => {
      startLotteryFlow("gesture");
    }
  });
}

function startLotteryFlow(source = "button") {
  if (isLotting) {
    if (source === "gesture") {
      addQipao("Розыгрыш уже идёт, жест запуска пропущен.");
    }
    return;
  }

  const message =
    source === "gesture"
      ? "Жест распознан! Запускаем розыгрыш, удачи!"
      : "Запускаем случайный розыгрыш, удачи!";

  Promise.resolve(saveData()).then(() => {
    if (availablePrizePool.length === 0) {
      addQipao("Все призы уже разыграны!");
      setLotteryStatus(false);
      btns.lottery.innerHTML = "Начать розыгрыш";
      return;
    }

    if (btns.lotteryBar.classList.contains("none")) {
      removeHighlight();
      rotate = true;
      switchScreen("lottery");
    }

    setLotteryStatus(true);
    resetCard().then(() => {
      rotateScene = true;
      spinStartedAt = Date.now();
      lottery();
    });
    addQipao(message);
  });
}

/**
 * Инициализация DOM
 */
function initAll() {
  window.AJAX({
    url: "/getTempData",
    success(data) {
      // Получение базовых данных
      prizes = data.cfgData.prizes;
      HIGHLIGHT_CELL = createHighlight();
      basicData.prizes = prizes;
      setPrizes(prizes);

      TOTAL_CARDS = ROW_COUNT * COLUMN_COUNT;

      // Загрузка сохранённых результатов
      basicData.leftUsers = data.leftUsers || [];

      initialisePrizeState(data.luckyData || {});
      showPrizeList();
      updateAllPrizeDisplays();
      currentPrize = null;
    }
  });

  window.AJAX({
    url: "/getUsers",
    success(data) {
      basicData.users = data;

      initCards();
      // startMaoPao();
      animate();
      shineCard();
    }
  });
}

function initCards() {
  cardPrizeLayout = buildCardEntries();

  let isBold = false,
    showTable = basicData.leftUsers.length === basicData.users.length,
    index = 0,
    position = {
      x: (140 * COLUMN_COUNT - 20) / 2,
      y: (180 * ROW_COUNT - 20) / 2
    };

  camera = new THREE.PerspectiveCamera(
    40,
    window.innerWidth / window.innerHeight,
    1,
    10000
  );
  camera.position.z = 3000;

  scene = new THREE.Scene();

  for (let i = 0; i < ROW_COUNT; i++) {
    for (let j = 0; j < COLUMN_COUNT; j++) {
      isBold = HIGHLIGHT_CELL.includes(j + "-" + i);
      var element = createCard(
        cardPrizeLayout[index] || {},
        isBold,
        index,
        showTable
      );

      var object = new THREE.CSS3DObject(element);
      object.position.x = Math.random() * 4000 - 2000;
      object.position.y = Math.random() * 4000 - 2000;
      object.position.z = Math.random() * 4000 - 2000;
      scene.add(object);
      threeDCards.push(object);
      //

      var object = new THREE.Object3D();
      object.position.x = j * 140 - position.x;
      object.position.y = -(i * 180) + position.y;
      targets.table.push(object);
      index++;
    }
  }

  // sphere

  var vector = new THREE.Vector3();

  for (var i = 0, l = threeDCards.length; i < l; i++) {
    var phi = Math.acos(-1 + (2 * i) / l);
    var theta = Math.sqrt(l * Math.PI) * phi;
    var object = new THREE.Object3D();
    object.position.setFromSphericalCoords(800 * Resolution, phi, theta);
    vector.copy(object.position).multiplyScalar(2);
    object.lookAt(vector);
    targets.sphere.push(object);
  }

  renderer = new THREE.CSS3DRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.getElementById("container").appendChild(renderer.domElement);

  //

  controls = new THREE.TrackballControls(camera, renderer.domElement);
  controls.rotateSpeed = 0.5;
  controls.minDistance = 500;
  controls.maxDistance = 6000;
  controls.addEventListener("change", render);

  bindEvent();
  ensureGestureControl();

  if (showTable) {
    switchScreen("enter");
  } else {
    switchScreen("lottery");
  }
}

function setLotteryStatus(status = false) {
  isLotting = status;
}

/**
 * Привязка событий
 */
function bindEvent() {
  document.querySelector("#menu").addEventListener("click", function (e) {
    e.stopPropagation();
    // Во время розыгрыша действия запрещены
    if (isLotting) {
      if (e.target.id === "lottery") {
        requestSmoothStop && requestSmoothStop();
        btns.lottery.innerHTML = "Начать розыгрыш";
      } else {
        addQipao("Идёт розыгрыш, подождите немного…");
      }
      return false;
    }

    let target = e.target.id;
    switch (target) {
      // Показать цифровую стену
      case "welcome":
        switchScreen("enter");
        rotate = false;
        break;
      // Перейти к розыгрышу
      case "enter":
        removeHighlight();
        addQipao("Скоро приступим к случайному розыгрышу, оставайтесь с нами.");
        // rotate = !rotate;
        rotate = true;
        switchScreen("lottery");
        break;
      // Сброс
      case "reset":
        let doREset = window.confirm(
          "Вы уверены, что хотите сбросить данные? Все текущие результаты будут очищены?"
        );
        if (!doREset) {
          return;
        }
        addQipao("Данные сброшены, начинаем заново");
        addHighlight();
        const resetAnimation = resetCard();
        // Сбросить все данные
        currentLuckys = [];
        selectedCardIndex = [];
        basicData.leftUsers = Object.assign([], basicData.users);
        basicData.luckyUsers = {};
        basicData.awardedCounts = {};
        initialisePrizeState({});
        Promise.resolve(resetAnimation).then(() => {
          refreshCardLayout();
        });
        currentPrize = null;

        resetPrize();
        updateAllPrizeDisplays();
        reset();
        switchScreen("enter");
        break;
      // Розыгрыш
      case "lottery":
        startLotteryFlow("button");
        break;
      // Переразыграть
      case "reLottery":
        if (currentLuckys.length === 0) {
          addQipao(`Ещё не было розыгрыша, переразыграть нельзя.`);
          return;
        }
        const lastRecord = currentLuckys[0];
        addQipao("Переразыгрываем приз, приготовьтесь");
        setLotteryStatus(true);
        resetCard().then(() => {
          if (lastRecord) {
            undoPrizeAward(lastRecord);
          }
          currentLuckys = [];
          selectedCardIndex = [];
          rotateScene = true;
          spinStartedAt = Date.now();
          lottery();
        });
        break;
      // Экспорт результатов
      case "save":
        saveData().then(res => {
          resetCard().then(res => {
            // Очистить предыдущие записи
            currentLuckys = [];
          });
          exportData();
          addQipao(`Данные сохранены в Excel.`);
        });
        break;
    }
  });

  window.addEventListener("resize", onWindowResize, false);
}

function switchScreen(type) {
  switch (type) {
    case "enter":
      btns.enter.classList.remove("none");
      btns.lotteryBar.classList.add("none");
      transform(targets.table, 2000);
      break;
    default:
      btns.enter.classList.add("none");
      btns.lotteryBar.classList.remove("none");
      transform(targets.sphere, 2000);
      break;
  }
}

/**
 * Создание элемента
 */
function createElement(css, text) {
  let dom = document.createElement("div");
  dom.className = css || "";
  dom.innerHTML = text || "";
  return dom;
}

/**
 * Создание карточки
 */
function createCard(entry, isBold, id, showTable) {
  var element = createElement();
  element.id = "card-" + id;

  if (isBold) {
    element.className = "element lightitem";
    if (showTable) {
      element.classList.add("highlight");
    }
  } else {
    element.className = "element";
    element.style.backgroundColor =
      "rgba(253,105,0," + (Math.random() * 0.35 + 0.15) + ")";
  }

  const label = entry && entry.label ? entry.label : "";
  setCardLabel(element, label);

  return element;
}

function removeHighlight() {
  document.querySelectorAll(".highlight").forEach(node => {
    node.classList.remove("highlight");
  });
}

function addHighlight() {
  document.querySelectorAll(".lightitem").forEach(node => {
    node.classList.add("highlight");
  });
}

/**
 * Рендер шара и прочего
 */
function transform(targets, duration) {
  // TWEEN.removeAll();
  for (var i = 0; i < threeDCards.length; i++) {
    var object = threeDCards[i];
    var target = targets[i];

    new TWEEN.Tween(object.position)
      .to(
        {
          x: target.position.x,
          y: target.position.y,
          z: target.position.z
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();

    new TWEEN.Tween(object.rotation)
      .to(
        {
          x: target.rotation.x,
          y: target.rotation.y,
          z: target.rotation.z
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();
  }

  new TWEEN.Tween(this)
    .to({}, duration * 2)
    .onUpdate(render)
    .start();
}

// function rotateBall() {
//   return new Promise((resolve, reject) => {
//     scene.rotation.y = 0;
//     new TWEEN.Tween(scene.rotation)
//       .to(
//         {
//           y: Math.PI * 8
//         },
//         ROTATE_TIME
//       )
//       .onUpdate(render)
//       .easing(TWEEN.Easing.Exponential.InOut)
//       .start()
//       .onComplete(() => {
//         resolve();
//       });
//   });
// }

function rotateBall() {
  return new Promise(resolve => {
    // Простое стабильное вращение за счёт рендера
    rotateScene = true;
    let stopped = false;

    // Плавная остановка к ближайшему полному обороту
    requestSmoothStop = () => {
      if (stopped) return;
      stopped = true;
      const twoPi = Math.PI * 2;
      const currentY = scene.rotation.y;
      const target = Math.ceil(currentY / twoPi) * twoPi;
      rotateScene = false; // перестаём подкручивать сцену в animate()
      new TWEEN.Tween(scene.rotation)
        .to({ y: target }, 1000)
        .easing(TWEEN.Easing.Quadratic.Out)
        .onUpdate(render)
        .onComplete(() => {
          scene.rotation.y = target;
          resolve();
        })
        .start();
    };
  });
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  render();
}

function animate() {
  // Вращение сцены по оси X/Y
  if (rotateScene) {
    // fallback rotation to ensure visible motion even if tween is interrupted
    scene.rotation.y += SPIN_SPEED;
  }

  requestAnimationFrame(animate);
  TWEEN.update();
  controls.update();

  // Цикл рендеринга
  render();
}

function render() {
  renderer.render(scene, camera);
}

function selectCard(duration = 600) {
  rotate = false;
  let width = 140,
    tag = -(currentLuckys.length - 1) / 2,
    locates = [];

  if (currentLuckys.length === 0) {
    setLotteryStatus();
    btns.lottery.innerHTML = "Начать розыгрыш";
    return;
  }

  // Вычисление позиций; >5 — в два ряда
  if (currentLuckys.length > 5) {
    let yPosition = [-87, 87],
      l = selectedCardIndex.length,
      mid = Math.ceil(l / 2);
    tag = -(mid - 1) / 2;
    for (let i = 0; i < mid; i++) {
      locates.push({
        x: tag * width * Resolution,
        y: yPosition[0] * Resolution
      });
      tag++;
    }

    tag = -(l - mid - 1) / 2;
    for (let i = mid; i < l; i++) {
      locates.push({
        x: tag * width * Resolution,
        y: yPosition[1] * Resolution
      });
      tag++;
    }
  } else {
    for (let i = selectedCardIndex.length; i > 0; i--) {
      locates.push({
        x: tag * width * Resolution,
        y: 0 * Resolution
      });
      tag++;
    }
  }

  const labels = currentLuckys.map(item => {
    if (!item) {
      return "";
    }
    if (item.label) {
      return item.label;
    }
    const info = prizeIndexMap.get(item.type);
    return (info && info.prize && info.prize.displayLabel) || "";
  });
  if (labels.length > 0) {
    addQipao(`Приз "${labels[0]}" нашёл своего победителя!`);
  }

  selectedCardIndex.forEach((cardIndex, index) => {
    changeCard(cardIndex, currentLuckys[index], { isWinner: true });
    var object = threeDCards[cardIndex];
    new TWEEN.Tween(object.position)
      .to(
        {
          x: locates[index].x,
          y: locates[index].y * Resolution,
          z: 2200
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();

    new TWEEN.Tween(object.rotation)
      .to(
        {
          x: 0,
          y: 0,
          z: 0
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();

    object.element.classList.add("prize");
    tag++;
  });

  new TWEEN.Tween(this)
    .to({}, duration * 2)
    .onUpdate(render)
    .start()
    .onComplete(() => {
      // После окончания анимации можно управлять
      setLotteryStatus();
      btns.lottery.innerHTML = "Начать розыгрыш";
      allowImmediateSpin();
    });
}

/**
 * Сброс содержимого карточек
 */
function resetCard(duration = 500) {
  if (currentLuckys.length === 0) {
    return Promise.resolve();
  }

  selectedCardIndex.forEach(index => {
    let object = threeDCards[index],
      target = targets.sphere[index];

    new TWEEN.Tween(object.position)
      .to(
        {
          x: target.position.x,
          y: target.position.y,
          z: target.position.z
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();

    new TWEEN.Tween(object.rotation)
      .to(
        {
          x: target.rotation.x,
          y: target.rotation.y,
          z: target.rotation.z
        },
        Math.random() * duration + duration
      )
      .easing(TWEEN.Easing.Exponential.InOut)
      .start();
  });

  return new Promise((resolve, reject) => {
    new TWEEN.Tween(this)
      .to({}, duration * 2)
      .onUpdate(render)
      .start()
      .onComplete(() => {
        selectedCardIndex.forEach(index => {
          let object = threeDCards[index];
          changeCard(index, cardPrizeLayout[index] || {});
          object.element.classList.remove("prize");
        });
        resolve();
      });
  });
}

/**
 * Розыгрыш
 */
function lottery() {
  btns.lottery.innerHTML = "Закончить розыгрыш";
  rotateBall().then(() => {
    currentLuckys = [];
    selectedCardIndex = [];

    const prizeRecord = drawPrizeFromPool();
    if (!prizeRecord) {
      addQipao("Все призы уже разыграны!");
      setLotteryStatus(false);
      btns.lottery.innerHTML = "Начать розыгрыш";
      return;
    }

    const prizeInfo = prizeIndexMap.get(prizeRecord.type);
    currentPrize = prizeInfo ? prizeInfo.prize : null;

    markPrizeAwarded(prizeRecord, { highlight: true });

    let cardIndex = random(TOTAL_CARDS);
    while (selectedCardIndex.includes(cardIndex)) {
      cardIndex = random(TOTAL_CARDS);
    }
    selectedCardIndex.push(cardIndex);

    currentLuckys = [
      Object.assign({}, prizeRecord, {
        cardIndex
      })
    ];

    selectCard();
  });
}

/**
 * Сохранить предыдущий результат
 */
function saveData() {
  if (!currentLuckys.length) {
    return Promise.resolve();
  }

  const record = currentLuckys[0];
  if (!record || typeof record.type === "undefined") {
    return Promise.resolve();
  }

  const type = record.type;
  const key = String(type);
  const curLucky = basicData.luckyUsers[key] || [];
  basicData.luckyUsers[key] = curLucky.concat(record);

  return setData(type, [record]);
}

/**
 * Случайный выбор
 */
function random(num) {
  // Равномерное распределение чисел 0..num-1
  return Math.floor(Math.random() * num);
}

/**
 * Смена данных на карточке
 */
function changeCard(cardIndex, entry = {}, options = {}) {
  const cardObj = threeDCards[cardIndex];
  if (!cardObj || !cardObj.element) {
    return;
  }
  const label = entry && entry.label ? entry.label : "";

  setCardLabel(cardObj.element, label);

  cardObj.element.classList.toggle("prize-note", !!options.isWinner);
}

/**
 * Смена фона карточки
 */
function shine(cardIndex, color) {
  let card = threeDCards[cardIndex].element;
  card.style.backgroundColor =
    color || "rgba(253,105,0," + (Math.random() * 0.35 + 0.15) + ")";
}

/**
 * Случайная смена фона и данных
 */
function shineCard() {
  let maxCard = 10,
    shineCard = 10 + random(maxCard);

  setInterval(() => {
    // Во время розыгрыша останавливаем мигание
    if (isLotting) {
      return;
    }
    for (let i = 0; i < shineCard; i++) {
      let cardIndex = random(TOTAL_CARDS);
      // Не менять случайно уже показанные карточки победителей
      if (selectedCardIndex.includes(cardIndex)) {
        continue;
      }
      shine(cardIndex);
      changeCard(cardIndex, cardPrizeLayout[cardIndex] || {});
    }
  }, 500);
}

function setData(type, data) {
  return new Promise((resolve, reject) => {
    window.AJAX({
      url: "/saveData",
      data: {
        type,
        data
      },
      success() {
        resolve();
      },
      error() {
        reject();
      }
    });
  });
}

function setErrorData(data) {
  return new Promise((resolve, reject) => {
    window.AJAX({
      url: "/errorData",
      data: {
        data
      },
      success() {
        resolve();
      },
      error() {
        reject();
      }
    });
  });
}

function exportData() {
  window.AJAX({
    url: "/export",
    success(data) {
      if (data.type === "success") {
        location.href = data.url;
      }
    }
  });
}

function reset() {
  window.AJAX({
    url: "/reset",
    success(data) {
      console.log("Сброс выполнен");
    }
  });
}

function createHighlight() {
  let year = String(DISPLAY_YEAR);
  let step = 4,
    xoffset = 1,
    yoffset = 1,
    highlight = [];

  year.split("").forEach(n => {
    highlight = highlight.concat(
      NUMBER_MATRIX[n].map(item => {
        return `${item[0] + xoffset}-${item[1] + yoffset}`;
      })
    );
    xoffset += step;
  });

  return highlight;
}

let onload = window.onload;

window.onload = function () {
  onload && onload();

  let music = document.querySelector("#music");

  let rotated = 0,
    stopAnimate = false,
    musicBox = document.querySelector("#musicBox");

  function animate() {
    requestAnimationFrame(function () {
      if (stopAnimate) {
        return;
      }
      rotated = rotated % 360;
      musicBox.style.transform = "rotate(" + rotated + "deg)";
      rotated += 1;
      animate();
    });
  }

  musicBox.addEventListener(
    "click",
    function (e) {
      if (music.paused) {
        music.play().then(
          () => {
            stopAnimate = false;
            animate();
          },
          () => {
            addQipao("Не удалось автоматически запустить музыку. Запустите вручную!");
          }
        );
      } else {
        music.pause();
        stopAnimate = true;
      }
    },
    false
  );

  setTimeout(function () {
    musicBox.click();
  }, 1000);
};
